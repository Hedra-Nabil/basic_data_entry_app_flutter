# 📝 Data Entry App

A beautiful, clean-architecture Flutter app for simple data entry and display.

![Flutter](https://img.shields.io/badge/Flutter-02569B?style=for-the-badge&logo=flutter&logoColor=white)
![Dart](https://img.shields.io/badge/Dart-0175C2?style=for-the-badge&logo=dart&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)

## 📱 Screenshots

<p align="center">
  <img src="screenshots/screenshot1.png" width="300" alt="Data Entry App"/>
</p>

## ✨ Features

- 📝 Simple text entry and submission
- 🎨 Beautiful purple gradient UI
- 📱 Responsive card-based layout
- ✅ Real-time text display
- 🏗️ Clean Architecture (Domain/Data/Presentation)
- 🎯 SOLID Principles applied

## 🏗️ Architecture

This project follows **Clean Architecture** principles:

```
lib/
├── main.dart
├── core/
│   ├── constants/
│   │   ├── app_dimensions.dart
│   │   └── app_strings.dart
│   ├── di/
│   │   └── dependency_injection.dart
│   └── theme/
│       ├── app_colors.dart
│       ├── app_text_styles.dart
│       └── app_theme.dart
└── features/
    └── data_entry/
        ├── data/
        │   ├── datasources/
        │   │   └── text_entry_local_datasource.dart
        │   └── repositories/
        │       └── text_entry_repository_impl.dart
        ├── domain/
        │   ├── entities/
        │   │   └── text_entry.dart
        │   ├── repositories/
        │   │   └── text_entry_repository.dart
        │   └── usecases/
        │       ├── get_current_entry_usecase.dart
        │       └── submit_text_usecase.dart
        └── presentation/
            ├── controllers/
            │   └── data_entry_controller.dart
            ├── screens/
            │   └── data_entry_screen.dart
            └── widgets/
                ├── header_card.dart
                ├── submit_button.dart
                ├── submitted_text_card.dart
                └── text_input_card.dart
```

## 📥 Download

Get the latest release:

[![Download APK](https://img.shields.io/badge/Download-APK-brightgreen?style=for-the-badge&logo=android)](https://github.com/Hedra-Nabil/basic_data_entry_app_flutter/releases/latest)

Or visit the [Releases Page](https://github.com/Hedra-Nabil/basic_data_entry_app_flutter/releases)

## 🚀 Getting Started

### Prerequisites

- Flutter SDK ^3.10.3
- Dart SDK ^3.10.3

### Installation

1. Clone the repository
```bash
git clone https://github.com/Hedra-Nabil/basic_data_entry_app_flutter.git
```

2. Navigate to project directory
```bash
cd basic_data_entry_app_flutter
```

3. Install dependencies
```bash
flutter pub get
```

4. Run the app
```bash
flutter run
```

## 🛠️ Build

To build the release APK:

```bash
flutter build apk --release
```

The APK will be generated at `build/app/outputs/flutter-apk/app-release.apk`

## 🎨 Design Highlights

| Feature | Description |
|---------|-------------|
| 🎨 **Color Scheme** | Purple gradient theme (#5C4CDB) |
| 📐 **Layout** | Card-based responsive design |
| ✨ **Animations** | Smooth loading states |
| 🔤 **Typography** | Clean, readable fonts |

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 👨‍💻 Author

**Hedra Nabil**

- GitHub: [@Hedra-Nabil](https://github.com/Hedra-Nabil)

---

> Made with ❤️ using Flutter
